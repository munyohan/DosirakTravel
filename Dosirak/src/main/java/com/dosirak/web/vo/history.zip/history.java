package com.dosirak.web.vo;

public class history {
	
	private int seq;
	private String kind;
	private String doingUser;
	private String friendUser;
	private int gold;
	private int code;
	private int price;
	private String actDate;
	
	public int getSeq() {
		return seq;
	}
	public void setSeq(int seq) {
		this.seq = seq;
	}
	public String getKind() {
		return kind;
	}
	public void setKind(String kind) {
		this.kind = kind;
	}
	public String getDoingUser() {
		return doingUser;
	}
	public void setDoingUser(String doingUser) {
		this.doingUser = doingUser;
	}
	public String getFriendUser() {
		return friendUser;
	}
	public void setFriendUser(String friendUser) {
		this.friendUser = friendUser;
	}
	public int getGold() {
		return gold;
	}
	public void setGold(int gold) {
		this.gold = gold;
	}
	public int getCode() {
		return code;
	}
	public void setCode(int code) {
		this.code = code;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	public String getActDate() {
		return actDate;
	}
	public void setActDate(String actDate) {
		this.actDate = actDate;
	}

}
